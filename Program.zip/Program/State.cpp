//
// Created by johto839 on 2023-12-06.
//

#include "State.h"

State::~State() = default;

void State::init_game(const int LevelSelect) {}
