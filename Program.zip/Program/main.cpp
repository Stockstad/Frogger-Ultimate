#include "GameManager.h"

int main() {

    GameManager::start();

    return 0;
}
